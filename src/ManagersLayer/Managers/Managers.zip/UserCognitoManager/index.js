const Manager = require("./UserCognitoManager");

module.exports = new Manager();
module.exports.UserCognitoManager = Manager;
