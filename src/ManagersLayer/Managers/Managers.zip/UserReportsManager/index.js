const Manager = require("./UserReport.manager");

module.exports = new Manager();
module.exports.UserReportManager = Manager;
