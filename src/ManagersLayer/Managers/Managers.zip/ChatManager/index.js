const Manager = require("./ChatManager");

module.exports = new Manager();
module.exports.ChatManager = Manager;