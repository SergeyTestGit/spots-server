const Manager = require("./ServiceProvidersManager");

module.exports = new Manager();
module.exports.ServiceProvidersManager = Manager;
