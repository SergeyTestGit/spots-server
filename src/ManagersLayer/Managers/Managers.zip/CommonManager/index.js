const Manager = require("./CommonManager");

module.exports = new Manager();
module.exports.CommonManager = Manager;
