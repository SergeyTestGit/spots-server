const Manager = require("./JobsArchiveManager");

module.exports = new Manager();
module.exports.JobsArchiveManager = Manager;
