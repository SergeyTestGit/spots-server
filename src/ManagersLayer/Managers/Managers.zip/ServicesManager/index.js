const Manager = require("./ServicesManager");

module.exports = new Manager();
module.exports.ServicesManager = Manager;
