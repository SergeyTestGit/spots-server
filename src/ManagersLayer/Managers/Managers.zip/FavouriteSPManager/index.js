const Manager = require("./FavouriteSPManager");

module.exports = new Manager();
module.exports.FavouriteSPManager = Manager;
