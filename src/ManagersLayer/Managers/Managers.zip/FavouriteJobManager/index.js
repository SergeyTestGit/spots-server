const Manager = require("./FavouriteJobManager");

module.exports = new Manager();
module.exports.FavouriteJobManager = Manager;
