const Manager = require("./UserDynamoDBManager");

module.exports = new Manager();
module.exports.UserDynamoDBManager = Manager;
