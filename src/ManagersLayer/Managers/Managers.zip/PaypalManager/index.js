const Manager = require("./Paypal.manager");

module.exports = new Manager();
module.exports.PaypalManager = Manager;
