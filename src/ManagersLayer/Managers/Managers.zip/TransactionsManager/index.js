const Manager = require("./Transaction.manager");

module.exports = new Manager();
module.exports.TransactionManager = Manager;
