const Manager = require("./PtsPriceManager");

module.exports = new Manager();
module.exports.PtsPriceManager = Manager;
