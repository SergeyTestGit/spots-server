const Manager = require("./NotificationManager");

module.exports = new Manager();
module.exports.NotificationManager = Manager;
