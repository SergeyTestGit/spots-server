const Manager = require("./JobReviewManager");

module.exports = new Manager();
module.exports.JobReviewManager = Manager;
