const Manager = require("./JobsIgnoreManager");

module.exports = new Manager();
module.exports.JobsIgnoreManager = Manager;
