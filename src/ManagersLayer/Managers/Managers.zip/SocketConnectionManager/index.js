const Manager = require('./SocketConnectionManager')

module.exports = new Manager()
module.exports.SocketConnectionManager = Manager