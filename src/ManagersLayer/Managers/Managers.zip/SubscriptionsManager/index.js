const Manager = require("./SubscriptionsManager");

module.exports = new Manager();
module.exports.SubscriptionsManager = Manager;
