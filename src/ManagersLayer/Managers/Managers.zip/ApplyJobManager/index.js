const Manager = require("./ApplyJobManager");

module.exports = new Manager();
module.exports.ApplyJobManager = Manager;
