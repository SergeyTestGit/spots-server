const Manager = require("./AuthManager");

module.exports = new Manager();
module.exports.AuthManager = Manager;
