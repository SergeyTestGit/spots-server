const Manager = require("./JobsManager");

module.exports = new Manager();
module.exports.JobsManager = Manager;
