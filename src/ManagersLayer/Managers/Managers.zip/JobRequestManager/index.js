const Manager = require("./JobRequestsManager");

module.exports = new Manager();
module.exports.JobRequestsManager = Manager;
