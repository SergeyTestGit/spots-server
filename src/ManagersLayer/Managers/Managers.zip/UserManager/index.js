const Manager = require("./UserManager");

module.exports = new Manager();
module.exports.UserManager = Manager;
